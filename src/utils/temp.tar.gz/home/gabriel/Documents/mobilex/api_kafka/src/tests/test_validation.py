from ..main import is_query_safe


def test_valid_queries():
    assert is_query_safe("SELECT * FROM users")
    assert is_query_safe("insert into table values (1)")
    assert is_query_safe("  update table set x=1")
    assert is_query_safe("DELETE FROM table")


def test_invalid_queries():
    assert not is_query_safe("DROP TABLE users")
    assert not is_query_safe("ALTER TABLE something")
    assert not is_query_safe("GRANT ALL")

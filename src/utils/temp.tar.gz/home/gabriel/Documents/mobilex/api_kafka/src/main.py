from typing import Union
from confluent_kafka import Consumer
import oracledb
import os
from logger import console_logger, LogLevel
import asyncio
import httpx
import concurrent.futures

CONSOLE = console_logger(name="API KAFKA", level=LogLevel.INFO)
ALLOWED_STATEMENTS = ("SELECT", "INSERT", "UPDATE", "DELETE")

KAFKA_TOPIC = os.environ["KAFKA_TOPIC"]
KAFKA_BOOTSTRAP_SERVERS = os.environ["KAFKA_BOOTSTRAP_SERVERS"]
EXTERNAL_API_URL = os.environ["EXTERNAL_API_URL"]


def __verify_allowed_statements(query: str) -> bool:
    return any(query.startswith(stmt) for stmt in ALLOWED_STATEMENTS)


def __verify_remove_semicolo(query: str) -> str:
    if query.endswith(";"):
        query.removesuffix(";")
    return query


def is_query_safe(sql) -> bool:
    clean_sql = sql.strip().upper()
    clean_sql = __verify_remove_semicolo(clean_sql)
    return __verify_allowed_statements(clean_sql)


def query_oracle(
    sql: str,
) -> Union[list[dict[str, Union[int, str, bool]]], dict[str, Union[int, str, bool]]]:
    dsn = oracledb.makedsn(
        os.environ["IP_DB"],
        os.environ["PORT_DB"],
        service_name=os.environ["SERVICE_NAME_DB"],
    )

    with oracledb.connect(
        user=os.environ["USERNAME_DB"],
        password=os.environ["PASSWORD_DB"],
        dsn=dsn,
        host=os.environ["IP_DB"],
    ) as connection:
        CONSOLE.debug("Connectio Success!")
        with connection.cursor() as cursor:
            cursor.execute(sql)
            if sql.strip().upper().startswith("SELECT"):
                columns = [col[0] for col in cursor.description]
                rows = cursor.fetchall()
                return [dict(zip(columns, row)) for row in rows]
            else:
                connection.commit()
                return {"status": "success", "rows_affected": cursor.rowcount}


async def query_oracle_async(sql, timeout=5):
    loop = asyncio.get_running_loop()
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return await asyncio.wait_for(
            loop.run_in_executor(pool, lambda: query_oracle(sql)), timeout=timeout
        )


async def post_to_api(data, client):
    try:
        response = await client.post(EXTERNAL_API_URL, json=data)
        response.raise_for_status()
        CONSOLE.info(f"[POST SUCCESS] Response: {response.text}")
    except Exception as e:
        CONSOLE.info(f"[POST ERROR] {e}")


async def worker(queue: asyncio.Queue, client: httpx.AsyncClient):
    while True:
        sql = await queue.get()
        CONSOLE.info(f"[WORKER] Processing SQL: {sql}")
        try:
            if not is_query_safe(sql):
                CONSOLE.info(f"[REJECTED] Invalid SQL: {sql}")
            else:
                result = query_oracle(sql)
                CONSOLE.info(f"[QUERY RESULT] {result}")
                await post_to_api(result, client)
        except Exception as e:
            CONSOLE.info(f"[WORKER ERROR] {e}")
        finally:
            queue.task_done()


async def consume_kafka(queue: asyncio.Queue):
    consumer = Consumer(
        {
            "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
            "group.id": "oracle-query-group",
            "auto.offset.reset": "earliest",
        }
    )
    consumer.subscribe([KAFKA_TOPIC])
    CONSOLE.info(f"[KAFKA] Listening on topic: {KAFKA_TOPIC}")

    try:
        while True:
            msg = consumer.poll(1.0)
            if msg is None:
                await asyncio.sleep(0.1)
                continue
            if msg.error():
                CONSOLE.info(f"[KAFKA ERROR] {msg.error()}")
                continue
            sql = msg.value().decode("utf-8").strip()
            await queue.put(sql)
    except asyncio.CancelledError:
        CONSOLE.info("[KAFKA] Shutting down gracefully...")
    finally:
        consumer.close()


async def main():
    queue = asyncio.Queue()
    num_workers = 5

    async with httpx.AsyncClient(timeout=10) as client:
        workers = [
            asyncio.create_task(worker(queue, client)) for _ in range(num_workers)
        ]
        consumer_task = asyncio.create_task(consume_kafka(queue))

        await asyncio.gather(consumer_task)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        CONSOLE.info("[MAIN] Stopped by user")

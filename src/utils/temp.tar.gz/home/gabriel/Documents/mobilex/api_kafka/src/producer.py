import os
from confluent_kafka import Producer


def delivery_report(err, msg):
    if err:
        print(f"Message failed delivery: {err}")
    else:
        print(f"Message delivered to {msg.topic()} [{msg.partition()}]")


producer = Producer({"bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS")})

sql_statements = [
    "INSERT INTO test_table (name) VALUES ('Alice')",
    "INSERT INTO test_table (name) VALUES ('Bob')",
    "SELECT * FROM test_table",
    "UPDATE test_table SET name = 'Charlie' WHERE name = 'Alice'",
    "DELETE FROM test_table WHERE name = 'Bob'",
    "DROP TABLE test_table",  # ← essa deve ser ignorada
]

for sql in sql_statements:
    producer.produce(
        os.getenv("KAFKA_TOPIC"), sql.encode("utf-8"), callback=delivery_report
    )

producer.flush()

import pytest
import httpx
from httpx import Response
from ..main import post_to_api


@pytest.mark.asyncio
async def test_post_to_api_success(monkeypatch):
    async def mock_post(*args, **kwargs):
        return Response(status_code=200, content=b'{"ok": true}')

    async with httpx.AsyncClient() as client:
        monkeypatch.setattr(client, "post", mock_post)
        response = await post_to_api({"test": "value"}, client)
        assert response == {"ok": True}
